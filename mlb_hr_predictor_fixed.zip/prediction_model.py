from overlays.weather import get_weather_factor
from overlays.park import get_park_factor
print(get_weather_factor('game1'))
print(get_park_factor('Coors Field'))

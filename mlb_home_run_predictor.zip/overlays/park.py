def get_park_factor(park_name):
    # Placeholder: load park factor from config or static file
    if park_name in ['Coors Field', 'Great American Ball Park']:
        return 1.20
    return 1.00
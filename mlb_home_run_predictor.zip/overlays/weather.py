def get_weather_factor(game_id):
    # Placeholder: fetch weather data based on game_id
    # Example logic: temp/wind/VPD affect flight
    return 1.05  # slightly favorable conditions